package Hotel;



public class Restaurant {

	public static void main(String[] args) {
		System.out.println("My Hotel");
		
	}

}

class FoodRestaurant extends Restaurant{}
class KFC extends FoodRestaurant{}
class GasBill{}
class Hotel{
	Food prepareFood()
	{
		Food foodObj = new Food();
		return foodObj;
	}
	FeedBackForm askFeedBackForm()
	{
		FeedBackForm feedbackObj = new FeedBackForm();
		return feedbackObj;
	}
	GasBill paygasbill()
	{
		GasBill gasbillObj = new GasBill();
		return gasbillObj;
	}
}

class Food{}

class FeedBackForm{}
class HolidayHome{
	Restaurant providesrestaurant()
	{
		Restaurant restaurantObj = new Restaurant();
		return restaurantObj;
	}
}