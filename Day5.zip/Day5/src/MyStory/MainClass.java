package MyStory;

import Company.Laptop;
import Company.Trading;
import Vehicle.TwoWheeler;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Trading tradingObj= new Trading();
		System.out.println(tradingObj.companyName);
		
		Laptop tradingLaptop=new Laptop();
		tradingLaptop.sellLaptop();	
		
		TwoWheeler twoWheelerObj=new TwoWheeler();
		twoWheelerObj.engine();	
	}

}
