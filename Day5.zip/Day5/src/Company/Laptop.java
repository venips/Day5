package Company;

public class Laptop  extends Trading{
	int laptopprice = 45;
	public Laptop sellLaptop() //hasA
	{
		System.out.println("Company trades Laptop");
		System.out.println("The Laptop company purchase price is :"+laptopprice);
		Laptop laptopObj = new Laptop();

		
		System.out.println("The Laptop selling price is :"+laptopObj.laptopprice);
		return laptopObj;
	}
}
