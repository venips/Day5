package Company;

public class Toy {
	Toy sellToy(){
		System.out.println("Company trades Toy");
		Toy toyObj = new Toy();
		return toyObj;
	}
}
