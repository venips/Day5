package Company;

public class AirConditioner {
	AirConditioner sellAirConditioner(){
		System.out.println("Company trades AirConditioner");
		AirConditioner airconditionerObj = new AirConditioner();
		return airconditionerObj;
	}
}
