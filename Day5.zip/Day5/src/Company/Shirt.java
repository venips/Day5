package Company;

public class Shirt {
	Shirt sellShirt(){
		System.out.println("Company trades Shirt");
		Shirt shirtObj = new Shirt();
	
		return shirtObj;
	}
}
