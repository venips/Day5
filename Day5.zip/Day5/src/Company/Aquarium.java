package Company;

public class Aquarium extends Trading{
	Aquarium sellAquarium(){
		System.out.println("Company trades Aquarium");
		Aquarium aquariumObj = new Aquarium();
		return aquariumObj;
	}
}
