package Company;


public  class Trading implements Company {
	 int laptopprice = 25000;

}


