package Company;

interface Company {
	 String companyName = "My Trading Company";
}
