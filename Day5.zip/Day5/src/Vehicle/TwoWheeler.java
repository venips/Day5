package Vehicle;

public class TwoWheeler extends Vehicle{

	@Override
	public 	void engine() {
		// TODO Auto-generated method stub
		System.out.println("Engine Name is HHABCBBBCBC");
	}

	

}
