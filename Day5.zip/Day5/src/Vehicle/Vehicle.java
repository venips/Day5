package Vehicle;

public abstract class Vehicle {
	abstract void engine();
}
